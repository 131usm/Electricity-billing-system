
package pkgnew.login.page.pkg1;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NewLoginPage1 {
    
    public static void main(String[] args) {
        JPanel panel=new JPanel();
        panel.setBackground(Color.gray);
        
        JFrame frame=new JFrame("Login Page");
        frame.setBounds(100,100,350,200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               
        frame.add(panel);
        panel.setLayout(null);
        
        JLabel userlabel=new JLabel("username");
       userlabel.setBounds(10, 20, 80, 25);
       panel.add(userlabel);
       
      JTextField text=new JTextField();
       text.setBounds(100, 20, 165, 25);
       panel.add(text);
       
        JLabel passwordlabel=new JLabel("Password");
      passwordlabel.setBounds(10, 50, 80, 25);
      panel.add(passwordlabel);
      
     JPasswordField passwordtext=new JPasswordField();
      passwordtext.setBounds(100,50,165,25);
      panel.add(passwordtext);
       
       JButton button=new JButton("Login");
      button.setBounds(10, 100, 80, 25);
      
      panel.add(button);
    
      JButton button2=new JButton("Cancel");
      button2.setBounds(100,100,80,25);
      
      panel.add(button2);
             
        frame.setVisible(true);
        
        JFrame frame2=new JFrame("New Customer Billing");
        frame2.setSize(600,600);
        frame2.setLayout(null);
        
        JPanel p2=new JPanel();
        p2.setBackground(Color.white);
        p2.setSize(650,600);
        frame2.add(p2);
        p2.setLayout(null);
        
       JLabel l1=new JLabel("Name");
       l1.setBounds(200,0,50,50);
       p2.add(l1);
       
       JTextField tf1=new JTextField("Usman zafar");
       tf1.setBounds(410,10,150,30);
       p2.add(tf1);
       
       JLabel l2=new JLabel("Meter no");
       l2.setBounds(200,70,50,50);
       p2.add(l2);
       
       JTextField tf2=new JTextField("1033");
       tf2.setBounds(410,80,150,30);
       p2.add(tf2);
       
       JLabel l3=new JLabel("Address");
       l3.setBounds(200,140,50,50);
       p2.add(l3);
       
       JTextField tf3=new JTextField("street no24");
       tf3.setBounds(410,150,150,30);
       p2.add(tf3);
       
       JLabel l4=new JLabel("State");
       l4.setBounds(200,210,50,50);
       p2.add(l4);
       
       JTextField tf4=new JTextField("Pakistan");
       tf4.setBounds(410,220,150,30);
       p2.add(tf4);
               
        JLabel l5=new JLabel("City");
       l5.setBounds(200,280,50,50);
       p2.add(l5);
       
       JTextField tf5=new JTextField("Islamabad");
       tf5.setBounds(410,290,150,30);
       p2.add(tf5);   
       
       JLabel l6=new JLabel("Email");
       l6.setBounds(200,350,50,50);
       p2.add(l6);
       
       JTextField tf6=new JTextField("usman123@gmail.com");
       tf6.setBounds(410,360,150,30);
       p2.add(tf6);    
       
       JLabel l7=new JLabel("Phone No");
       l7.setBounds(200,410,70,50);
       p2.add(l7);
       
       JTextField tf7=new JTextField("03022000731");
       tf7.setBounds(410,420,150,30);
       p2.add(tf7); 
       
       JButton b5=new JButton(new ImageIcon("C:\\Users\\user\\Downloads\\login page image.png"));
              b5.setBounds(0,120,150,300);
              b5.setBackground(Color.white);
              b5.setLayout(null);
              p2.add(b5);
              
       JButton b3=new JButton("Submit");
       b3.setBounds(200,490,160,30);
       b3.setBackground(Color.black);
       b3.setForeground(Color.white);
       p2.add(b3);
       
       JButton b4=new JButton("cancel");
       b4.setBounds(410,490,160,30);
       b4.setBackground(Color.black);
       b4.setForeground(Color.white);
       p2.add(b4);
       
       JFrame f3=new JFrame("Calculate bill");
      f3.setSize(600,600);
     
      
      JPanel p3=new JPanel();
        p3.setBackground(Color.white);
        p3.setSize(650,600);
        f3.add(p3);
        p3.setLayout(null);
        
        JButton b6=new JButton(new ImageIcon("C:\\Users\\user\\Downloads\\bill calculate.png"));
        b6.setBounds(0,140,150,300);
        b6.setBackground(Color.white);
        b6.setLayout(null);
        p3.add(b6);
        
        JLabel l8=new JLabel("Meter no");
       l8.setBounds(200,140,50,50);
       p3.add(l8);
       
       String s1[]={"1003","1004","1005","1006","1007","1008","1009","1010","1011","1012"};
       JComboBox cb1=new JComboBox(s1);
       cb1.setBounds(410,150,150,30);
       p3.add(cb1);
       
       JLabel l9=new JLabel("Month");
       l9.setBounds(200,230,50,50);
       p3.add(l9);
       
       String s2[]={"Jan","Feb","Mar","April","May","June","July","Aug","Sep","Oct","Nov","Dec"};
       JComboBox cb2=new JComboBox(s2);
       cb2.setBounds(410,240,150,30);
       p3.add(cb2);
       
       JLabel l10=new JLabel("Unit consumed");
       l10.setBounds(200,330,100,50);
       p3.add(l10);
       
       JTextField tf8=new JTextField();
       tf8.setBounds(410,320,150,80);
       p3.add(tf8); 
       
       JButton b7=new JButton("Submit");
      
       b7.setBounds(200,450,160,70);
       b7.setBackground(Color.black);
       b7.setForeground(Color.white);
       p3.add(b7);
       
       JButton b8=new JButton("cancel");
       b8.setBounds(410,450,160,70);
       b8.setBackground(Color.black);
       b8.setForeground(Color.white);
       p3.add(b8);
       
       JButton b9=new JButton(new ImageIcon("C:\\Users\\user\\Pictures\\al imag new.jpg"));
        b9.setBounds(170,0,240,130);
        b9.setBackground(Color.white);
        b9.setLayout(null);
        p3.add(b9);
        
        JFrame f4=new JFrame("Electricity Billing System");
        
        f4.setSize(1000,667);
        f4.setLayout(null);
        
        JLabel l22=new JLabel(new ImageIcon("C:\\Users\\user\\Downloads\\new back.jpg"));
        l22.setSize(1000,667);
        l22.setLayout(null);
       
        JPanel p1=new JPanel();
        p1.setSize(1000,667);
        p1.setLayout(null);
        f4.add(p1);
         p1.add(l22);
         
         JMenuBar mb=new JMenuBar();
         
         JMenu master=new JMenu("Master");
         master.setForeground(Color.blue);
         
         JMenu user=new JMenu("User");
         user.setForeground(Color.red);
         
         JMenu report=new JMenu("Report");
         report.setForeground(Color.blue);
         
         JMenu utility=new JMenu("Utility");
         utility.setForeground(Color.red);
         
         JMenu exit=new JMenu("Exit");
         exit.setForeground(Color.blue);
      
         JMenuItem i1=new JMenuItem("Login page");
          JMenuItem i2=new JMenuItem("New customer billing");
           JMenuItem i3=new JMenuItem("Calculate bill");
           JMenuItem i4=new JMenuItem("bill Details");
            JMenuItem i5=new JMenuItem("complain");
            JMenuItem i6=new JMenuItem("note pad");
             JMenuItem i7=new JMenuItem("calculator");
           
           master.add(i1);
           master.add(i2);
           user.add(i3);
           user.add(i4);
           report.add(i5);
           utility.add(i6);
           utility.add(i7);
           
           mb.add(master);
           mb.add(user);
           mb.add(report);
           mb.add(utility);
           mb.add(exit);
           
           f4.setJMenuBar(mb);
           
           i1.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        frame.setVisible(true);
          }
        });
           
            i2.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        frame2.setVisible(true);
          }
        });
            
             i3.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        f3.setVisible(true);
          }
        });
           
        JFrame f5=new JFrame("bill details");
        f5.setSize(500,400);
        f5.setLayout(null);
        
        JPanel pp1=new JPanel();
        pp1.setSize(500,400);
        
        pp1.setBackground(Color.white);
        f5.add(pp1);
        //JLabel label1=new JLabel(new ImageIcon("C:\\Users\\user\\Pictures\\paid bill.jpg"));
        //label1.setBounds(100,100,167,238);
        //f5.add(label1);
        
        JCheckBox bo=new JCheckBox("Bank name");
        
        bo.setBounds(150,80,150,40);
        f5.add(bo);
        
         bo.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
            
              JOptionPane.showMessageDialog(f5, "you have deposited your money in Habib Bank Limited");
        
          }
        });
        
        
        JCheckBox bo1=new JCheckBox("Cash deposit");
        bo1.setBounds(150,140,150,40);
        f5.add(bo1);
        
         bo1.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              JOptionPane.showMessageDialog(f5, "you have deposited Rs.6000");
       
          }
        });
        
        JCheckBox bo2=new JCheckBox("Date of submission");
        bo2.setBounds(150,200,150,40);
        f5.add(bo2);
        
         bo2.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
              JOptionPane.showMessageDialog(f5, "you have paid the bill on 12/02/20");
        
          }
        });
        
        i4.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        f5.setVisible(true);
          }
        });
        
        JFrame f6=new JFrame("Complain sector");
        f6.setSize(600,500);
        f6.setLayout(null);
        
        JLabel label2=new JLabel("==> write your complain?");
        label2.setBounds(0,100,150,100);
        f6.add(label2);
       
        label2.setLayout(null);
        
        JLabel label9=new JLabel(new ImageIcon("C:\\Users\\user\\Pictures\\121.png"));
        label9.setBounds(300,0,238,224);
         f6.add(label9);
        
        JPanel pp=new JPanel();
        pp.setBounds(300,0,238,224);
        pp.add(label9);
          f6.add(pp);
       
        JTextField textf=new JTextField();
        textf.setBounds(0,190,250,150);
        f6.add(textf);
        textf.setLayout(null);
        
        JButton but=new JButton("submit");
        but.setBounds(250,350,100,40);
        
        but.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              JOptionPane.showMessageDialog(f6, "Your complain has been recieved your problem will be resolve within 2 days");
        f6.setVisible(true);
          }
        });
        
        f6.add(but);
        but.setLayout(null);
        
        i5.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        f6.setVisible(true);
          }
        });
      
       /*  JButton b11=new JButton(new ImageIcon("C:\\Users\\user\\Pictures\\ tgnks.jpg"));
        b11.setBounds(170,200,240,130);
        b11.setBackground(Color.white);
        b11.setLayout(null);
        f4.add(b11);*/
        
       b3.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              
        f3.setVisible(true);
          }
        });
       
       b7.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              JOptionPane.showMessageDialog(f4, "Your bill has been paid");
        f4.setVisible(true);
          }
        });
       
       
 
       button.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent u){
              Connection conn = null;
        ResultSet rs = null;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn = DriverManager.getConnection("jdbc:ucanaccess://D:\\my sql\\Name1.accdb");

            String sql = "select * from Table1 where Username='" + text.getText() + "' and Password='" + passwordtext.getText() + "'";
            Statement s = conn.createStatement();
            rs = s.executeQuery(sql);
            if (rs.next()) {
                frame2.setVisible(true);
                
            } else {
                JOptionPane.showMessageDialog(null, "invalid user name or password");
            }
        } catch (Exception ex) {
            System.out.println("error exception");
            System.out.println(ex.getMessage());
        }
        
          }
          
       });  
   }
    
}


